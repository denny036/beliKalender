<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php /**PATH E:\#KULIAH\#Semester 5\KEPAL\Proyek\beliKalender\BeliKalender\resources\views/layouts/alert/_alert_success.blade.php ENDPATH**/ ?>