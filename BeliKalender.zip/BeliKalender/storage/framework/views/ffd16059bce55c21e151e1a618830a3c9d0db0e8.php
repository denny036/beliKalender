<?php $__env->startComponent('mail::message'); ?>
# Mari aktivasi akun Anda!

Hai <?php echo e($user->name); ?>,

Berikut kode OTP Anda <b><?php echo e($user->token_activation); ?></b><br>
Silakan masukkan kode OTP tersebut untuk melakukan verifikasi akun Anda.



Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH E:\#KULIAH\#Semester 5\KEPAL\Proyek\beliKalender\BeliKalender\resources\views/emails/auth/activation.blade.php ENDPATH**/ ?>