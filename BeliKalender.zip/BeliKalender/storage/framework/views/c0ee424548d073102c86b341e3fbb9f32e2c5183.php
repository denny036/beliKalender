<?php echo e($slot); ?>

<?php /**PATH E:\#KULIAH\#Semester 5\KEPAL\Proyek\beliKalender\BeliKalender\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>