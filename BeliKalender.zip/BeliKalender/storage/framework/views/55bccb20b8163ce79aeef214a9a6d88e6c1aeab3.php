<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    Daftar Produk

                    <a href="<?php echo e(route('product.create')); ?>" class="btn btn-sm btn-success float-right">Tambah Produk</a>

                </div>

                <div class="card-body">

                    <table class="table table-bordered">
                        <tr>
                            <th class="text-center">ID Produk</th>
                            <th class="text-center">Nama Produk</th>
                            <th class="text-center">Deskripsi Produk</th>
                            <th class="text-center">Gambar Produk</th>
                            <th class="text-center">Jumlah Produk</th>
                            <th class="text-center">Harga</th>
                            <th class="text-center">Action</th>
                        </tr>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($item->id); ?></td>
                            <td class="text-center"><?php echo e($item->nama); ?></td>
                            <td class="text-center"><?php echo e($item->deskripsi); ?></td>
                            <td class="text-center"><img src="<?php echo e(asset('images/produk/' . $item->gambar)); ?>"
                                    alt="Gambar Produk" height="80" width="80"></td>
                            <td class="text-center"><?php echo e($item->jumlah); ?></td>
                            <td class="text-center"><?php echo e($item->harga); ?></td>
                            <td class="text-center">

                                <a href="<?php echo e(route('product.edit', $item->id)); ?>" class="btn btn-sm btn-warning">Edit</a>


                                    <form action="<?php echo e(route('product.delete',$item->id)); ?>" class="d-inline"
                                         method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <a href="<?php echo e(route('product.delete',$item->id)); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus data?')">Hapus</a>
                                    </form>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script src="https://demo.getstisla.com/assets/modules/sweetalert/sweetalert.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.slim.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.2/umd/popper.min.js"></script>

<script>
    $(".swal-confirm").click(function(e) {
        id = e.target.dataset.id;
        swal({
            title: 'Anda yakin hapus data ini?',
            text: 'Anda tidak dapat mengembalikan data ini jika sudah dihapus.',
            icon: 'warning',
            buttons: true,
            dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    swal('Produk donasi berhasil dihapus!', {
                        icon: 'success',
                    });
                    $(`#delete${id}`).submit();
                } else {
                    swal('Donasi Anda tidak jadi dihapus!');
                }
            });
        });
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\#KULIAH\#Semester 5\KEPAL\Proyek\beliKalender\BeliKalender\resources\views/penjual/home.blade.php ENDPATH**/ ?>