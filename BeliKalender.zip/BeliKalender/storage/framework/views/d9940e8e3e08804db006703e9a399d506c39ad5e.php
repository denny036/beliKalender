<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <?php if($message = Session::get('sukses')): ?>
        <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert"> ×</button>
            <strong><?php echo e($message); ?></strong>
        </div>
        <?php endif; ?>
        <div class="col-md-12 mb-4">
            <img src="<?php echo e(asset('images/logo.png')); ?>" class="rounded mx-auto d-block" width="500" alt="">
        </div>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card">
                <img src="<?php echo e(asset('images/produk/' . $item->gambar)); ?>" class="card-img-top responsive" width="200px"
                    height="200px" style="object-fit: cover" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($item->nama); ?></h5>
                    <p class="card-text">
                        <strong>Harga :</strong> Rp. <?php echo e(number_format($item->harga)); ?>

                        <hr>
                        <strong>Stok :</strong> <?php echo e($item->jumlah); ?>

                        <br>
                        <strong>Keterangan :</strong>
                        <?php echo e($item->deskripsi); ?>

                    </p>
                    <a href="<?php echo e(route('pembeli.add-to-carts', $item->id)); ?>" class="btn btn-primary"><i
                            class="fas fa-shopping-cart"></i> Pesan</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.slim.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.2/umd/popper.min.js"></script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\#KULIAH\#Semester 5\KEPAL\Proyek\beliKalender\BeliKalender\resources\views/pembeli/index.blade.php ENDPATH**/ ?>