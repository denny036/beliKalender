<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <a href="<?php echo e(route('pembeli.index')); ?>" class="btn btn-sm btn-primary float-right"><i
                    class="fa fa-arrow-left"></i>Kembali</a>
        </div>
        <div class="col-md-12 mt-2">
            <nav aria-label="breadcrumb">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('pembeli.index')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Checkout</li>
                </ol>
                
            </nav>
        </div>
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <h3><i class="fa fa-shopping-cart"></i>Checkout Sekarang!</h3>
                    <?php if(!empty($transaction)): ?>
                    <p>Tanggal Pemesanan: <?php echo e(date('d-m-Y', strtotime($transaction->tanggal))); ?></p>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Barang</th>
                                <th>Jumlah</th>
                                <th>Harga</th>
                                <th>Total Harga</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; ?>
                            <?php $__currentLoopData = $detail_transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($item->produk->nama); ?></td>
                                <td><?php echo e($item->jumlah); ?> buah</td>
                                <td>Rp. <?php echo e(number_format($item->produk->harga)); ?></td>
                                <td>Rp. <?php echo e(number_format($item->jumlah_harga)); ?></td>
                                <td>
                                    <form action="<?php echo e(route('pembeli.delete-from-carts', $item->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field("DELETE"); ?>
                                        <button type="submit" class="btn btn-sm btn-danger"><i
                                                class="fa fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="4" align="right"><strong>Total Harga: </strong></td>
                                <td><strong>Rp. <?php echo e(number_format($transaction->jumlah_harga)); ?></strong></td>
                                <td>
                                    <form action="<?php echo e(route('pembeli.checkout')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="sumbit" class="btn btn-sm btn-success"><i class="fa fa-shopping-cart"></i> Checkout</button>
                                    </form>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\#KULIAH\#Semester 5\KEPAL\Proyek\beliKalender\BeliKalender\resources\views/pembeli/carts.blade.php ENDPATH**/ ?>