<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <a href="<?php echo e(route('pembeli.index')); ?>" class="btn btn-sm btn-primary float-right"><i
                    class="fa fa-arrow-left"></i>Kembali</a>
                    <a href="<?php echo e(route('pembeli.carts')); ?>" class="btn btn-sm btn-danger float-left"><i
                        class="fa fa-shopping-cart"></i> Lihat Keranjang</a>
        </div>
        <div class="col-md-12 mt-2">
            <nav aria-label="breadcrumb">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('pembeli.index')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($barang->nama); ?></li>
                </ol>
                <?php if($message = Session::get('info-jumlah')): ?>
                <div class="alert alert-warning">
                    <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>
            </nav>
        </div>
        <div class="col-md-12 mt-3">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mx-auto">
                            <img src="<?php echo e(asset('images/produk/' . $barang->gambar)); ?>"
                                class="rounded mx-auto d-block" width="100%" alt="">
                        </div>
                        <div class="col-md-6 mt-5">
                            <h2><?php echo e($barang->nama); ?></h2>
                            <table class="table">
                                <tbody>
                                    
                                    <tr>
                                        <td>Harga</td>
                                        <td>:</td>
                                        <td>Rp. <?php echo e((number_format($barang->harga))); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Stok</td>
                                        <td>:</td>
                                        <td><?php echo e(number_format($barang->jumlah)); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Keterangan</td>
                                        <td>:</td>
                                        <td><?php echo e($barang->deskripsi); ?></td>
                                    </tr>

                                        <?php echo csrf_field(); ?>
                                        <tr>
                                            <td>Jumlah Pesan</td>
                                            <td>:</td>
                                            <td>
                                                <form action="<?php echo e(route('create.add-to-carts', $barang->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input class="form-control" type="text" name="jumlah_pesan"
                                                    required="">
                                                    <button type="submit" class="btn btn-primary mt-3"><i
                                                        class="fa fa-shopping-cart"></i> Masukkan Keranjang</button>
                                                </form>
                                            </td>
                                        </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\#KULIAH\#Semester 5\KEPAL\Proyek\beliKalender\BeliKalender\resources\views/pembeli/checkout.blade.php ENDPATH**/ ?>